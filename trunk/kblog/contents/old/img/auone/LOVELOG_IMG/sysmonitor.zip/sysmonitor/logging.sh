#!/bin/sh

BASE=`dirname $0`
MBMON=/usr/local/bin/mbmon
GAWK=/usr/local/bin/gawk

LOGDIR=ログ用ディレクトリ
LOGTIME=3600
INT=ログ間隔(秒)
AWKPARAM="-v logdir=$LOGDIR -v timeout=$LOGTIME -v interval=$INT"

top -s $INT -d 100 -bu 0 | $GAWK $AWKPARAM -f $BASE/logging-top.awk &
$MBMON $INT           | $GAWK $AWKPARAM -f $BASE/logging-mbmon.awk &
netstat -w $INT       | $GAWK $AWKPARAM -f $BASE/logging-netstat.awk &
iostat -x -w $INT -d  | $GAWK $AWKPARAM -f $BASE/logging-iostat.awk &
