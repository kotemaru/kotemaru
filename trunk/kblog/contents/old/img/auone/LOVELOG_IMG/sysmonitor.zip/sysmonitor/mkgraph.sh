#!/bin/sh

BASE=`dirname $0`
LOGDIR=ログ用ディレクトリ
OUTDIR=グラフ出力先ディレクトリ
DATE=`date -v -1H +%Y-%m-%d`
GNUPLOT=/usr/local/bin/gnuplot

$BASE/plot-top.awk   $LOGDIR/top-$DATE.log   | $GNUPLOT > $OUTDIR/top-$DATE.png
$BASE/plot-mbmon.awk $LOGDIR/mbmon-$DATE.log | $GNUPLOT > $OUTDIR/mbmon-$DATE.png
$BASE/plot-disk.awk  $LOGDIR/disk-$DATE.log  | $GNUPLOT > $OUTDIR/disk-$DATE.png
$BASE/plot-net.awk   $LOGDIR/net-$DATE.log   | $GNUPLOT > $OUTDIR/net-$DATE.png

cd $OUTDIR
rm -f *-current.png
ln -s top-$DATE.png   top-current.png 
ln -s mbmon-$DATE.png mbmon-current.png 
ln -s disk-$DATE.png  disk-current.png 
ln -s net-$DATE.png   net-current.png 

